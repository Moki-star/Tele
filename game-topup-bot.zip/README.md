# Telegram Game Top-up Bot

This bot allows users to order top-ups like BRL or UC and submit KBZPay screenshots. Admins can verify and send redeem codes.

## Setup

```bash
pip install -r requirements.txt
python bot.py
```

Edit `config.env` with your bot token and admin ID.
